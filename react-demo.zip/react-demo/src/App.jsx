import { Layout } from "./Layout.jsx";
import Menu from "./Menu.jsx";

export default function App() {
  return (
    <Layout>
      <Menu/>
    </Layout>
  )
}
